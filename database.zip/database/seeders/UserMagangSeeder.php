<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class UserMagangSeeder extends Seeder
{
    public function run(): void
    {
        // Gembok Keamanan Lapisan Kedua
        if (app()->isProduction()) {
            $this->command->warn('Peringatan: UserMagangSeeder dihentikan! Tidak boleh memasukkan akun dummy mahasiswa ke production.');
            return;
        }

        /**
         * =========================================================
         * MEMBUAT FILE DUMMY FISIK
         * =========================================================
         */
        if (!Storage::disk('public')->exists('cv_uploads/dummy.pdf')) {
            Storage::disk('public')->put('cv_uploads/dummy.pdf', 'Ini adalah file CV dummy untuk keperluan testing.');
        }

        if (!Storage::disk('public')->exists('proposal_uploads/dummy.pdf')) {
            Storage::disk('public')->put('proposal_uploads/dummy.pdf', 'Ini adalah file Proposal dummy untuk keperluan testing.');
        }

        /**
         * =========================================================
         * SEEDING DATA USER & PROFILE
         * =========================================================
         */
        for ($i = 1; $i <= 20; $i++) {
            $userId = DB::table('users_magang')->insertGetId([
                'username' => 'user' . $i,
                'email' => 'user' . $i . '@test.com',
                'password_hash' => Hash::make('password123'),
                // TIKET VIP: Anggap saja mereka sudah verifikasi email saat ini juga!
                'email_verified_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            DB::table('profiles_magang')->insert([
                'user_id' => $userId,
                'full_name' => 'Test User ' . $i,
                'education_level' => 'S1',
                'nim_nisn' => 'NIM' . $i,
                'institution_name' => 'Universitas Test',
                'major' => 'Informatika',
                'phone_number' => '08123456789',
                'address' => 'Alamat Testing',
                'cv_file_path' => 'cv_uploads/dummy.pdf',
                'proposal_file_path' => 'proposal_uploads/dummy.pdf',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
