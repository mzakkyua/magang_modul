<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssessmentMagang extends Model
{
    protected $table = 'assessments_magang';

    /**
     * =====================================================
     * MASS ASSIGNMENT
     * =====================================================
     */
    protected $fillable = [
        'member_id',
        'assessor_name',
        'score_behavior',
        'score_discipline',
        'score_performance',
        'evaluation_notes',
        'additional_notes'
    ];

    /**
     * =====================================================
     * CASTING
     * =====================================================
     */
    protected $casts = [
        'score_behavior'    => 'float',
        'score_discipline'  => 'float',
        'score_performance' => 'float',
        'final_score'       => 'float',
    ];

    /**
     * =====================================================
     * AUTO CALCULATE FINAL SCORE
     * =====================================================
     */
    protected static function booted()
    {
        static::saving(function ($model) {

            $scores = array_filter([
                $model->score_behavior,
                $model->score_discipline,
                $model->score_performance
            ], fn($score) => is_numeric($score));

            $model->final_score = count($scores) > 0
                ? round(array_sum($scores) / count($scores), 2)
                : 0;
        });
    }

    /**
     * =====================================================
     * RELATION: MEMBER
     * =====================================================
     */
    public function member()
    {
        return $this->belongsTo(ApplicationMemberMagang::class, 'member_id');
    }

    /**
     * =====================================================
     * HELPER: CHECK PASS
     * =====================================================
     */
    public function isPassed()
    {
        return $this->final_score >= 70;
    }
}
