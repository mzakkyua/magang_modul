<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| IMPORT CONTROLLER
|--------------------------------------------------------------------------
*/

// ---------------------
// UMUM & PESERTA MAGANG
// ---------------------
use App\Http\Controllers\AuthMagangController;
use App\Http\Controllers\DashboardMagangController;
use App\Http\Controllers\ProfileMagangController;
use App\Http\Controllers\ApplicationMagangController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\StatusMagangController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\CertificateController;

// ---------------------
// ADMIN DINAS
// ---------------------
use App\Http\Controllers\Admin\VacancyMagangController;
use App\Http\Controllers\Admin\ApplicationVerificationController;
use App\Http\Controllers\Admin\DivisionSettingController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AssessmentController;
use App\Http\Controllers\Admin\AdminProfileController;
use App\Http\Controllers\Admin\PegawaiController;
use App\Http\Controllers\Admin\PesertaController;
use App\Http\Controllers\Admin\DivisionController;
use App\Http\Controllers\Admin\ImportPesertaController;

// ---------------------
// AUTH RESET PASSWORD
// ---------------------
use App\Http\Controllers\Requests\Auth\ForgotPasswordMagangController;
use App\Http\Controllers\Requests\Auth\ResetPasswordMagangController;
use App\Http\Controllers\Requests\Auth\ForgotPasswordAdminController;
use App\Http\Controllers\Requests\Auth\ResetPasswordAdminController;

/*
|--------------------------------------------------------------------------
| WEB ROUTES
|--------------------------------------------------------------------------
|
| Seluruh routing aplikasi magang.
|
| ZONA:
|   1. Reset Password  — publik, tidak butuh login
|   2. Logout          — universal multi-guard
|   3. Publik          — landing page & kalender
|   4. Guest Peserta   — login & register (hanya jika belum login)
|   5. Auth Peserta    — area peserta yang sudah login (guard: magang)
|   6. Admin           — area admin dinas (guard: web + admin.magang)
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| RESET PASSWORD
|--------------------------------------------------------------------------
| Tidak butuh login — akses dengan token dari email.
|--------------------------------------------------------------------------
*/

Route::prefix('password')->group(function () {

    Route::get('/forgot', [ForgotPasswordMagangController::class, 'showLinkRequestForm'])
        ->name('password.request');

    Route::post('/email', [ForgotPasswordMagangController::class, 'sendResetLinkEmail'])
        ->name('password.email')
        ->middleware('throttle:5,1'); // max 5 request reset per menit

    Route::get('/reset/{token}', [ResetPasswordMagangController::class, 'showResetForm'])
        ->name('password.reset');

    Route::post('/reset', [ResetPasswordMagangController::class, 'reset'])
        ->name('password.update');
});

/*
|--------------------------------------------------------------------------
| RESET PASSWORD (ADMIN DINAS)
|--------------------------------------------------------------------------
*/
Route::prefix('admin/password')->name('admin.password.')->group(function () {
    Route::get('/forgot', [ForgotPasswordAdminController::class, 'showLinkRequestForm'])
        ->name('request');

    Route::post('/email', [ForgotPasswordAdminController::class, 'sendResetLinkEmail'])
        ->name('email')
        ->middleware('throttle:5,1'); // Maksimal 5 kali minta email per menit

    Route::get('/reset/{token}', [ResetPasswordAdminController::class, 'showResetForm'])
        ->name('reset');

    Route::post('/reset', [ResetPasswordAdminController::class, 'reset'])
        ->name('update');
});

/*
|--------------------------------------------------------------------------
| LOGOUT UNIVERSAL
|--------------------------------------------------------------------------
| IMPROVEMENT: Dipindah ke controller agar:
|   - Testable (bisa unit test method logout)
|   - Audit log bisa ditambahkan di controller
|   - php artisan route:cache tidak protes closure
|   - Konsisten dengan controller lain
|
| Method AuthMagangController::logout() menangani:
|   - guard web (admin)
|   - guard magang (peserta)
|   - session invalidate + regenerate token
|--------------------------------------------------------------------------
*/
Route::post('/logout', [AuthMagangController::class, 'logout'])
    ->name('logout');


/*
|--------------------------------------------------------------------------
| 1. ZONA PUBLIK
|--------------------------------------------------------------------------
| Bisa diakses tanpa login.
|--------------------------------------------------------------------------
*/
Route::get('/', [LandingController::class, 'index'])
    ->name('landing.index');

Route::get('/lowongan/{vacancy}', [LandingController::class, 'show'])
    ->name('landing.show');



/*
|--------------------------------------------------------------------------
| CALENDAR USER 
|--------------------------------------------------------------------------
| Harus Login Sebagai Peserta Magang, tapi TIDAK HARUS VERIFIED.
| Karena kalender juga menampilkan event selain yang berkaitan dengan magang, seperti workshop, seminar
|--------------------------------------------------------------------------
*/

Route::middleware(['auth:magang', 'verified'])->group(function () {

    Route::get('/calendar', [CalendarController::class, 'index'])
        ->name('calendar');

    Route::get('/calendar/events', [CalendarController::class, 'fetch'])
        ->name('calendar.events')
        ->middleware('throttle:60,1');
});

/*
|--------------------------------------------------------------------------
| RUTE VERIFIKASI EMAIL (MOBILE-FRIENDLY / TANPA LOGIN)
|--------------------------------------------------------------------------
| Memungkinkan peserta klik link dari HP tanpa harus login terlebih dahulu.
*/
Route::get('/email/verify/{id}/{hash}', function (Illuminate\Http\Request $request, $id, $hash) {
    // 1. Cari user berdasarkan ID di link
    $user = \App\Models\UserMagang::findOrFail($id);

    // 2. Cocokkan kunci rahasia (hash) di link dengan email user
    if (! hash_equals((string) $hash, sha1($user->getEmailForVerification()))) {
        abort(403, 'Link verifikasi tidak valid, rusak, atau sudah diubah!');
    }

    // 3. Jika belum verifikasi, tandai sebagai terverifikasi sekarang
    if (! $user->hasVerifiedEmail()) {
        $user->markEmailAsVerified();
        event(new \Illuminate\Auth\Events\Verified($user));
    }

    // 4. Tampilkan halaman sukses!
    return view('auth.magang-verify-success');
})->middleware('signed')->name('verification.verify');

/*
|--------------------------------------------------------------------------
| 2. ZONA GUEST PESERTA MAGANG
|--------------------------------------------------------------------------
| Hanya untuk peserta yang BELUM login (guard: magang).
| Jika sudah login → otomatis redirect oleh middleware guest:magang.
|--------------------------------------------------------------------------
*/
Route::middleware('guest:magang')->group(function () {

    Route::get('/login', [AuthMagangController::class, 'showLoginForm'])
        ->name('login');

    // IMPROVEMENT: throttle sebagai defense in depth di level route
    // RateLimiter di controller sudah ada, ini lapisan kedua
    Route::post('/login', [AuthMagangController::class, 'login'])
        ->name('login.post')
        ->middleware('throttle:10,1');

    Route::get('/register', [AuthMagangController::class, 'showRegisterForm'])
        ->name('register');

    Route::post('/register', [AuthMagangController::class, 'register'])
        ->name('register.post')
        ->middleware('throttle:5,1');
});


/*
|--------------------------------------------------------------------------
| 3. ZONA AUTH PESERTA MAGANG
|--------------------------------------------------------------------------
| Peserta yang sudah login (guard: magang).
|--------------------------------------------------------------------------
*/
Route::middleware('auth:magang')->group(function () {

    // ==========================================================
    // AREA BEBAS (TIDAK DIGEMBOK VERIFIED)
    // ==========================================================

    // 1. Halaman Peringatan Verifikasi
    Route::get('/email/verify', function (Request $request) {
        if ($request->user('magang')->hasVerifiedEmail()) {
            return redirect()->route('dashboard.index');
        }
        return view('auth.magang-verify-email');
    })->name('verification.notice');


    // 3. Tombol Kirim Ulang Email (INI YANG SEBELUMNYA HILANG!)
    Route::post('/email/verification-notification', function (Request $request) {
        $request->user('magang')->sendEmailVerificationNotification();
        return back()->with('status', 'verification-link-sent');
    })->middleware('throttle:6,1')->name('verification.send');

    // 4. Jalur Pengecekan Rahasia (AJAX) untuk Auto-Redirect
    Route::get('/email/check-status', function (Illuminate\Http\Request $request) {
        return response()->json([
            'verified' => $request->user('magang')->hasVerifiedEmail()
        ]);
    })->name('verification.check');

    // ==========================================================
    // AREA TERGEMBOK (WAJIB KLIK EMAIL DULU)
    // ==========================================================
    Route::middleware('verified')->group(function () {

        // Pindahkan SEMUA rute aplikasi peserta ke dalam grup ini!

        // Dashboard
        Route::get('/dashboard', [DashboardMagangController::class, 'index'])
            ->name('dashboard.index');

        Route::get('/dashboard/lowongan/{id}', [DashboardMagangController::class, 'show'])
            ->name('dashboard.show');

        // Profil
        Route::get('/profile', [ProfileMagangController::class, 'edit'])
            ->name('profile.edit');

        Route::put('/profile', [ProfileMagangController::class, 'update'])
            ->name('profile.update');

        Route::delete('/profile/delete-cv', [ProfileMagangController::class, 'deleteCv'])
            ->name('profile.delete.cv');

        Route::get('/profile/cv', [ProfileMagangController::class, 'serveCv'])
            ->name('profile.cv.view');

        // Pendaftaran magang
        Route::post('/applications', [ApplicationMagangController::class, 'store'])
            ->name('applications.store')
            ->middleware('throttle:10,1');

        // Status lamaran
        Route::get('/status', [StatusMagangController::class, 'index'])
            ->name('status');

        // Nilai
        Route::get('/nilai', [DashboardMagangController::class, 'nilai'])
            ->name('nilai');

        // Sertifikat Peserta
        Route::get('/sertifikat', [CertificateController::class, 'index'])
            ->name('certificates.index');

        Route::get('/sertifikat/{certificate}/view', [CertificateController::class, 'view'])
            ->name('certificates.view');

        Route::get('/sertifikat/{certificate}/download', [CertificateController::class, 'download'])
            ->name('certificates.download');

        Route::get('/vacancies/{vacancy}/snapshot', [LandingController::class, 'snapshot'])
            ->middleware(['throttle:60,1'])
            ->name('vacancies.snapshot');
    });
});


/*
|--------------------------------------------------------------------------
| 4. ZONA ADMIN DINAS
|--------------------------------------------------------------------------
| Guard: web + middleware admin.magang.
| Superadmin & admin divisi dibedakan di dalam controller.
|--------------------------------------------------------------------------
*/
Route::prefix('admin')
    ->name('admin.')
    ->middleware(['auth:web', 'admin.magang'])
    ->group(function () {

        // Dashboard
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])
            ->name('dashboard');

        // ==========================================================
        // RUTE PANDUAN ADMIN DI SINI
        // ==========================================================
        Route::get('/baca-panduan', function () {
            $path = storage_path('app/secure-docs/guidebook-admin.pdf');

            // Cek fisik file di sisi backend server
            if (!file_exists($path) || filesize($path) < 1024) {
                return back()->withErrors([
                    'error' => "Gagal memuat dokumen. File 'guidebook-admin.pdf' tidak ditemukan atau corrupt di server. Silakan upload ulang file melalui File Manager cPanel."
                ]);
            }

            // Tampilkan secara aman ke browser admin jika lolos pengecekan
            return response()->file($path, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="guidebook-admin.pdf"'
            ]);
        })->name('guidebook.view');
        // ==========================================================

        // Kalender admin
        Route::get('/calendar', [CalendarController::class, 'indexAdmin'])
            ->name('calendar.index');
        Route::post('/calendar', [CalendarController::class, 'store'])
            ->name('calendar.store');
        Route::put('/calendar/{event}', [CalendarController::class, 'update'])
            ->name('calendar.update');
        Route::delete('/calendar/{event}', [CalendarController::class, 'destroy'])
            ->name('calendar.destroy');

        // CRUD Lowongan
        Route::resource('vacancies', VacancyMagangController::class);
        Route::patch('/vacancies/{vacancy}/toggle', [VacancyMagangController::class, 'toggleStatus'])
            ->name('vacancies.toggle');
        Route::patch('/vacancies/{vacancy}/archive', [VacancyMagangController::class, 'archive'])
            ->name('vacancies.archive');

        // Verifikasi Lamaran
        Route::get('/applications', [ApplicationVerificationController::class, 'index'])
            ->name('applications.index');

        // ✅ Route spesifik DULU sebelum route dengan {parameter}
        Route::get('/applications/files/cv/{userId}', [ApplicationVerificationController::class, 'serveCv'])
            ->name('applications.files.cv')       // ← hapus 'admin.' di depan
            ->whereNumber('userId');

        Route::get('/applications/files/proposal/{userId}', [ApplicationVerificationController::class, 'serveProposal'])
            ->name('applications.files.proposal') // ← hapus 'admin.' di depan
            ->whereNumber('userId');

        // ✅ Route dengan {parameter} BELAKANGAN
        Route::get('/applications/{application}', [ApplicationVerificationController::class, 'show'])
            ->name('applications.show');

        Route::patch('/applications/{application}/update-status', [ApplicationVerificationController::class, 'updateStatus'])
            ->name('applications.update-status');

        // Penilaian Peserta
        Route::get('/assessments', [AssessmentController::class, 'index'])
            ->name('assessments.index');
        Route::get('/assessments/{member}/create', [AssessmentController::class, 'create'])
            ->name('assessments.create');
        Route::post('/assessments/{member}/store', [AssessmentController::class, 'store'])
            ->name('assessments.store');

        // Profil Admin
        Route::get('/profile', [AdminProfileController::class, 'index'])
            ->name('profile');
        Route::put('/profile', [AdminProfileController::class, 'update'])
            ->name('profile.update');

        /*
        | Sertifikat Admin
        |
        | IMPROVEMENT: Naming distandarkan ke certificates.* (plural)
        | agar konsisten dengan assessments.* dan vacancies.*
        */
        Route::get('/certificate/create', [CertificateController::class, 'create'])
            ->name('certificates.create');
        Route::post('/certificate', [CertificateController::class, 'store'])
            ->name('certificates.store');

        // Manajemen Pegawai & Hak Akses
        Route::get('/pegawai', [PegawaiController::class, 'index'])
            ->name('pegawai.index');
        Route::post('/pegawai/{id}/access', [PegawaiController::class, 'storeAccess'])
            ->name('pegawai.access.store');
        Route::delete('/pegawai/{id}/access', [PegawaiController::class, 'destroyAccess'])
            ->name('pegawai.access.destroy');

        // Kelola Kuota Divisi
        Route::get('/division-settings', [DivisionSettingController::class, 'index'])
            ->name('division-settings.index');

        Route::patch('/division-settings/{divisionSetting}', [DivisionSettingController::class, 'update'])
            ->name('division-settings.update');

        // Di dalam group middleware admin
        Route::get('/peserta', [PesertaController::class, 'index'])
            ->name('peserta.index');

        Route::get('/peserta/export', [PesertaController::class, 'export'])
            ->name('peserta.export');

        Route::get('/peserta/import/template', [ImportPesertaController::class, 'downloadTemplate'])
            ->name('peserta.import.template');
        Route::post('/peserta/import', [ImportPesertaController::class, 'store'])
            ->name('peserta.import.store');

        Route::get('/peserta/{member}', [PesertaController::class, 'show'])
            ->name('peserta.show');

        /*
|--------------------------------------------------------------------------
| Master Divisi Magang
|--------------------------------------------------------------------------
|
| Source of truth seluruh division_name.
| Hanya superadmin yang dapat mengelola.
|
*/
        Route::prefix('divisions')
            ->name('divisions.')
            ->group(function () {

                Route::get('/', [DivisionController::class, 'index'])
                    ->name('index');

                Route::post('/', [DivisionController::class, 'store'])
                    ->name('store');

                Route::put('/{division}', [DivisionController::class, 'update'])
                    ->name('update');

                Route::patch('/{division}/toggle-active', [DivisionController::class, 'toggleActive'])
                    ->name('toggle-active');

                Route::delete('/{division}', [DivisionController::class, 'destroy'])
                    ->name('destroy');
            });
    });
